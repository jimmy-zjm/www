$(function(){
	$("body").append('<div class="mask"><div class="imgbox"><img src=""></div></div>');
	   var mask=$(".mask");
       var maskimg=mask.find("img");
    $(".imgclick").click(function(){
        console.log(123);
         var src=$(this).find("img").attr("data-src");
         maskimg.attr("src",src);
         mask.show();
    });
    mask.click(function(){
        mask.hide();
    });
});